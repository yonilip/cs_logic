""" (c) This file is part of the course
    Mathematical Logic through Programming
    by Gonczarowski and Nisan.
    File name: code/propositions/syntax.py """

def is_variable(s):
    """ Is s an atomic proposition?  """
    return s[0] >= 'p' and s[0] <= 'z' and (len(s) == 1 or s[1:].isdigit())

def is_unary(s):
    """ Is s a unary operator? """
    return s == '~'

def is_binary(s):
    """ Is s a binary operator? """
    return s == '&' or s == '|' 

def is_constant(s):
    """ Is s a constant? """
    return s == 'T' or s == 'F'

class Formula:
    """ A Propositional Formula """

    def __init__(self, root, first=None, second=None):
        """ Create a new formula from its root (a string) and, when needed, the
        first and second operands (each of them a Formula)."""
        if is_constant(root) or is_variable(root):
            assert first is None and second is None
            self.root = root
        elif is_unary(root):
            assert type(first) is Formula and second is None
            self.root, self.first = root, first
        else:
            assert is_binary(root) and type(first) is Formula and type(second) is Formula
            self.root, self.first, self.second = root, first, second

    def __repr__(self):
        return self.infix()

    def __eq__(self, other):
        return self.infix()==other.infix()

    def __ne__(self, other):
        return not self == other

    def infix(self):
        """ Return an infix representation of self """
        # Task 1.1

    @staticmethod
    def from_infix(s):
        """ Return a propositional formula whose infix representation is s """
        # Task 1.2

    def prefix(self):
        """ Return a prefix representation of self """
        # Task 1.3

    @staticmethod
    def from_prefix(s):
        """ Return a propositional formula whose prefix representation is s """
        # Task 1.4

    def variables(self):
        """ Return the set of atomic propositions (variables) used in self """
        # Task 1.5
